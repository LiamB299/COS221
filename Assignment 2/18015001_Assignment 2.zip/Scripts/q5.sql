select CarID, Description 
from Cars
where YearModel="2020"