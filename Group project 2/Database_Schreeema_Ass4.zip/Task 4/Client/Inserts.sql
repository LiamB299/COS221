Delete from Client;

Insert into Client values 
('1', 'SmallBusiness','CD1', 'Corp', 'C1', '1999-11-01', '2001-11-01', '24', '1', '2', '2'),
('2', 'Corporate','CD2', 'BigCorp', 'C2', '2022-11-01', '2023-11-01', '24', '1', '2', '2'),
('3', 'MultiCorporate','CD3', 'MegaCorp', 'C3', '2013-11-01', '2015-11-01', '24', '1', '2', '2'),
('4', 'MultiCorporate','CD4', 'BiggestCorp', 'C4', '2019-11-01', '2025-11-01', '24', '1', '2', '2')
;

/* insert anomalie Contracts */
/* modification anomaly responsible employee */
/* delete anomaly contract */